from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
from rest_framework.permissions import IsAuthenticated
from django_filters import filterset

from .models import GroupModel,GroupChatModel, Message
from .serializer import GroupSerializer,GroupChatSerializer,GroupListSerializer,MessageSerializer
from .permissions import IsInGroup
# Create your views here.


class GroupView(viewsets.ModelViewSet):

    queryset = GroupModel.objects.all()
    serializer_class = GroupSerializer
    permission_classes = [IsAuthenticated]
    filter_fields = ["id"]




class GroupChatView(viewsets.ModelViewSet):

    queryset = GroupChatModel.objects.all()
    serializer_class = GroupChatSerializer
    filter_fields = ["group_id"]
        # permission_classes = [IsInGroup]



class GroupListView(viewsets.ModelViewSet):

    queryset = GroupModel.objects.all()
    serializer_class = GroupListSerializer
    # permission_classes = [IsInGroup]
    # filter_fields = ["id"]

    # def list(self, request):
    #     queryset = GroupModel.objects.filter(group_members = self.request.user)
    #     if not queryset:
    #         return JsonResponse({"message":"empty"},status = status.HTTP_400_BAD_REQUEST)
    #     # queryset = EventlikeModel.objects.filter()

    #     serializer = GroupListSerializer(queryset, many=True)
    #     return Response(serializer.data)







class MessageView(viewsets.ModelViewSet):


    queryset = Message.objects.all()
    serializer_class = MessageSerializer
    filter_fields = ["groupInt","groupid"]